﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LoginApp.Data
{
    public interface IUserService
    {
        string RegisterUser(string userName, string email, string password);

        string Login(string userName, string password);
    }
}
