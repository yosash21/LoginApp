﻿using LoginApp.Data;
using System;
using System.Linq;

namespace LoginApp.Service
{
    public class UserService : IUserService
    {
        private LoginContext _context;

        public UserService(LoginContext context)
        {
            _context = context;
        }

        public string Login(string userName, string password)
        {
            var user = GetUserByName(userName);
            if (user == null || user.Password != password)
                return "Username or Password are incorrect"; 

            return null;
        }

        public string RegisterUser(string userName, string email, string password)
        {
            var user = GetUserByName(userName);
            if (user != null)
                return "This username exist in the system"; 

            user = new User
            {
                UserName = userName,
                Email = email,
                Password = password
            };

            _context.Add(user);
            _context.SaveChanges();

            return null;
        }

        public User GetUserByName(string userName)
        {
            return _context.Users.FirstOrDefault(u => u.UserName == userName);
        }
    }
}
