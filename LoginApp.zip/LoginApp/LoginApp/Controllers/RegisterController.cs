﻿using LoginApp.Data;
using LoginApp.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginApp.Controllers
{
    public class RegisterController : Controller
    {
        IUserService _users;

        public RegisterController(IUserService users)
        {
            _users = users;
        }

        public IActionResult Register()
        {
            ModelState.Clear();
            return View();
        }

        [HttpPost]
        public IActionResult Register(RegisterUser registerUser)
        {
            if (!ModelState.IsValid)
                return View(registerUser);

            var result = _users.RegisterUser(registerUser.UserName, registerUser.Email, registerUser.Password);

            if (string.IsNullOrEmpty(result))
            {
                return RedirectToAction("Index", "Home");
            }

            ViewBag.ErrorMessage = result;
            return View(registerUser);
        }
    }
}
