﻿using LoginApp.Data;
using LoginApp.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginApp.Controllers
{
    public class LoginController :  Controller
    {
        IUserService _users;

        public LoginController(IUserService users)
        {
            _users = users;
        }

        public IActionResult Login()
        {
            ModelState.Clear();
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginUser loginUser)
        {
            if (!ModelState.IsValid)
                return View(loginUser);

            var result = _users.Login(loginUser.UserName, loginUser.Password);

            if (string.IsNullOrEmpty(result))
            {
                return RedirectToAction("Index", "Home");
            }

            ViewBag.ErrorMessage = result;
            return View(loginUser);
        }
    }
}
